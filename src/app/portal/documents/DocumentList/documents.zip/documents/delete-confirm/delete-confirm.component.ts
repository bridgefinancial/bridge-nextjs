import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { MatBottomSheetRef } from '@angular/material/bottom-sheet';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-delete-confirm',
  standalone: true,
  imports: [CommonModule, MatButtonModule],
  templateUrl: './delete-confirm.component.html',
  styleUrl: './delete-confirm.component.scss',
})
export class DeleteConfirmComponent {
  constructor(private bottomSheetRef: MatBottomSheetRef<DeleteConfirmComponent>) {}

  close(event: MouseEvent): void {
    event.preventDefault();
    this.bottomSheetRef.dismiss(false);
  }

  handleConfirm(event: MouseEvent): void {
    event.preventDefault();
    this.bottomSheetRef.dismiss(true);
  }
}
