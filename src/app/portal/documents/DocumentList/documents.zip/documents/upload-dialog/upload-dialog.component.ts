import { DropzoneComponent } from '@/app/components/dropzone/dropzone.component';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { Component, Inject } from '@angular/core';

@Component({
  selector: 'app-upload-dialog',
  standalone: true,
  imports: [CommonModule, MatDialogModule, MatButtonModule, MatIconModule, DropzoneComponent],
  templateUrl: './upload-dialog.component.html',
  styleUrl: './upload-dialog.component.scss',
})
export class UploadDialogComponent {
  public SUPPORTED_FILE_TYPES = [
    'application/pdf',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/csv',
  ];

  public uploadedFiles: File[] = [];
  public errors: string[] = [];

  formatFileSize(bytes: number): string {
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes === 0) return '0 Byte';
    const i = Math.floor(Math.log(bytes) / Math.log(1024));
    return parseFloat((bytes / Math.pow(1024, i)).toFixed(2)) + ' ' + sizes[i];
  }

  handleNewFiles(files: FileList): void {
    this.clearErrors();
    for (let i = 0; i < files.length; ++i) {
      const file = files.item(i);
      if (!file) return;
      if (this.SUPPORTED_FILE_TYPES.includes(file.type)) {
        !this.uploadedFiles.find((f) => f.name === file.name) && this.uploadedFiles.push(file);
      } else {
        this.errors.includes(file.type) || this.errors.push(file.type);
      }
    }
  }

  handleRemoveFileAtIndex(index: number) {
    this.uploadedFiles.splice(index, 1);
  }

  clearErrors() {
    this.errors = [];
  }
}
