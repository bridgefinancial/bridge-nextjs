import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { UploadDialogComponent } from './upload-dialog/upload-dialog.component';
import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { DeleteConfirmComponent } from './delete-confirm/delete-confirm.component';
import { BreakpointObserver, Breakpoints, LayoutModule } from '@angular/cdk/layout';
import { DeleteConfirmDialogComponent } from './delete-confirm-dialog/delete-confirm-dialog.component';
import { HttpClient } from '@angular/common/http';
import { environment } from '@/environments/environment';

type Document = {
  id: number;
  created_at: string;
  updated_at: string;
  file: string;
  description: string;
  company: number;
};

@Component({
  selector: 'app-documents',
  standalone: true,
  imports: [LayoutModule, CommonModule, MatButtonModule, MatIconModule],
  templateUrl: './documents.component.html',
  styleUrl: './documents.component.scss',
})
export class DocumentsComponent implements OnInit {
  public isMobile = false;
  public documents: Document[] = [];

  constructor(
    public dialog: MatDialog,
    private bottomSheet: MatBottomSheet,
    private breakpointObserver: BreakpointObserver,
    private http: HttpClient,
  ) {}

  ngOnInit(): void {
    this.breakpointObserver.observe([Breakpoints.Large, Breakpoints.Medium, Breakpoints.Small]).subscribe((result) => {
      if (result.matches) {
        if (result.breakpoints[Breakpoints.Small]) {
          this.isMobile = true;
        } else if (result.breakpoints[Breakpoints.Large] || result.breakpoints[Breakpoints.Medium]) {
          this.isMobile = false;
        }
      } else {
        this.isMobile = false;
      }
    });
    this.http.get(`${environment['DJANGO_API_BASE_URL']}/api/company-files/`).subscribe({
      next: (response: any) => {
        this.documents = response.results;
      },
      error: (err) => {
        console.error('Error fetching documents', err);
      },
    });
  }

  public getDate(date: string): string | null {
    if (!date) return null;
    return new Date(date).toLocaleDateString('en-us');
  }

  public handleViewDocument(doc: Document) {
    const a = document.createElement('a');
    a.href = doc.file;
    a.download = doc.description;
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  handleOpenDelete(event: MouseEvent): void {
    event.stopPropagation();
    if (this.isMobile) {
      const dialogRef = this.bottomSheet.open(DeleteConfirmComponent, { panelClass: 'MaterialDialog--rounded' });
      dialogRef.afterDismissed().subscribe((confirmed: boolean) => {
        if (confirmed) this.handleDeleteDocument();
      });
    } else {
      const dialogRef = this.dialog.open(DeleteConfirmDialogComponent, {
        panelClass: 'MaterialDialog--rounded',
        data: { text: 'Are you sure you want to delete this file?' },
      });
      dialogRef.afterClosed().subscribe((confirmed: boolean) => {
        if (confirmed) {
          this.handleDeleteDocument();
        }
      });
    }
  }

  handleDeleteDocument(): void {
    this.http.delete(`${environment['DJANGO_API_BASE_URL']}/api/company-files/${this.documents[0].id}`).subscribe({
      next: () => {
        this.documents = this.documents.filter((doc) => doc.id !== this.documents[0].id);
      },
      error: (err) => {
        console.error('Error deleting document', err);
      },
    });
  }

  handleOpenUpload() {
    const dialogRef = this.dialog.open(UploadDialogComponent, { panelClass: 'MaterialDialog--rounded' });
    dialogRef.afterClosed().subscribe((files: File[]) => {
      if (files) this.handleUploadDocuments(files);
    });
  }

  handleUploadDocuments(files: File[]): void {
    files.map((file) => {
      const formData = new FormData();
      formData.append('file', file);

      // use description as file name for now
      formData.append('description', file.name);
      return this.http.post(`${environment['DJANGO_API_BASE_URL']}/api/company-files/`, formData).subscribe({
        next: (response: any) => {
          this.documents.push(response);
        },
        error: (err) => {
          console.error('Error uploading document', err);
        },
      });
    });
  }
}
