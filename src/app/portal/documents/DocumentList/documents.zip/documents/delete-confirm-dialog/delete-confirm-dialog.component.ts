import { CommonModule } from '@angular/common';
import { Component, Inject, Input } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-confirm-dialog',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatDialogModule],
  templateUrl: './delete-confirm-dialog.component.html',
  styleUrl: './delete-confirm-dialog.component.scss',
})
export class DeleteConfirmDialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: { text: string },
    private dialogRef: MatDialogRef<DeleteConfirmDialogComponent>,
  ) {}

  close(event: MouseEvent): void {
    event.preventDefault();
    this.dialogRef.close(false);
  }

  handleConfirm(event: MouseEvent): void {
    event.preventDefault();
    this.dialogRef.close(true);
  }
}
